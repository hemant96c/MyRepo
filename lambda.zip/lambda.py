import boto3
import requests
import base64
import json

def lambda_handler(event, context):

    # Construct the data payload
    payload = {
        "userId": 146,
        "id": 100,
        "title": "For test purpose",
        "body": "Call from hemant"
    }

    # Convert the payload to JSON
    json_payload = json.dumps(payload)

    # Make a POST request to the remote API endpoint
    url = "https://jsonplaceholder.typicode.com/posts"
    headers = {
        "Content-Type": "application/json"
    }

    response = requests.post(url, headers=headers, data=json_payload)

    # Retrieve the response data
    response_data = response.json()

    # Print the response data
    print("Response Data:", response_data)

    return {
        "statusCode": response.status_code,
        "body": json.dumps(response_data),  # Include the response data in the return body
        "Message" : "API endpoint invoked successfully"
    }
